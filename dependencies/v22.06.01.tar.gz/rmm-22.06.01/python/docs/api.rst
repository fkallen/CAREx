API Reference
==============

High-level API
--------------

.. automodule:: rmm.rmm
   :members:
   :undoc-members:
   :show-inheritance:


Memory Resources
----------------

.. automodule:: rmm.mr
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: rmm
   :members:
   :undoc-members:
   :show-inheritance:
