#!/bin/bash

cmake --install build
