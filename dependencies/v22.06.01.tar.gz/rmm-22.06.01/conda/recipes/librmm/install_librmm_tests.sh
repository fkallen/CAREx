#!/bin/bash

cmake --install build --component testing
